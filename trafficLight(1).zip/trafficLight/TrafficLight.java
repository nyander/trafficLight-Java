import drawingTools.*;

/**
 * Write a description of class TrafficLight here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class TrafficLight
{
    // instance variables
    private Circle red;
    private Circle yellow;
    private Circle green;
    private boolean stop;

    /**
     * Constructor for objects of class TrafficLight
     */
    public TrafficLight()
    {
        // Construct the circles
        // Set their color and make them visible
        // Set stop to be true;
    }
    
    /**
     * If the traffic light shows STOP, it changes to GO.
     * Use the pause method after each step
     * If the traffic light shows GO, it changes to STOP.
     */
    public void change() {
        // read the instructions for the user story 
        // of how this method should work
    }
    
    /*
     * Do not change anything in the pause method
     */
    private void pause() {
        try {
            Thread.sleep(2000);
        } catch (InterruptedException e) {
        }
    }
}
