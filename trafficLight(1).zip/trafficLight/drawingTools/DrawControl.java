package drawingTools;

public interface DrawControl {
	public void draw();
	public void erase();
}
